package com.example.musicapp

data class ArtistX(
    val external_urls: ExternalUrlsXXX,
    val id: String,
    val name: String,
    val type: String,
    val uri: String
)