package com.example.musicapp;

import android.app.Activity;

public class SplashScreen extends Activity {
}
