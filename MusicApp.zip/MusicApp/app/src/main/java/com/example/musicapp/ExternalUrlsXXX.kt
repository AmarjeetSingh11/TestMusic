package com.example.musicapp

data class ExternalUrlsXXX(
    val spotify: String
)