package com.example.musicapp

data class ExternalIds(
    val isrc: String
)