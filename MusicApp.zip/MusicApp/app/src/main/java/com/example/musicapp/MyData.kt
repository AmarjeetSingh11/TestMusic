package com.example.musicapp

data class MyData(
    val tracks: List<Track>
)